Doc: Data Loaders
=================

Datasets
---------

.. autoclass:: onmt.io.TextDataset
    :members:

.. autoclass:: onmt.io.ImageDataset
    :members:

.. autoclass:: onmt.io.AudioDataset
    :members:
