"""Module defining decoders."""
